

The `cmake` script present in this directory offers the following options :

- `BUILD_XXHSUM` : build the command line binary. ON by default
- `BUILD_SHARED_LIBS` : build a dynamic library. OFF by default, builds static library instead.
