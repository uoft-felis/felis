#include <cstdio>
#include <gtest/gtest.h>

TEST(EpochCollectionTest, Test) {
  EXPECT_EQ(true, false);
}
